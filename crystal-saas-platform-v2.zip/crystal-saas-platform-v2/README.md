# Crystal SaaS Platform — UI Refresh (V2)

A polished full-stack business management dashboard built with Angular 17, TypeScript, Chart.js, Spring Boot 3, Java 17, Spring Data JPA, and H2. This V2 is a separate iteration of the original assessment project, with refined spacing, responsive tables, stronger card hierarchy, improved dark mode, more consistent controls, and clearer copy.

## Screens and functionality

- **Dashboard:** Total Sale, Active Orders, and Low Stock Items cards; online/offline revenue chart; customer satisfaction chart; Today / This week / This month filters.
- **Sales:** five KPI cards, All / Week / Day filters, month selector, selectable report rows, status badges, pagination, View action, and CSV export.
- **Customers:** searchable, paginated table; select rows; create, edit, and delete customers; confirmation before deletion; required-field, email, phone, and receivables validation.
- **Shared layout:** collapsible sidebar, active route state, search field, quick actions, notifications, profile, light/dark theme, and responsive desktop/tablet/mobile layouts.
- **Backend:** REST APIs, Controller → Service → Repository layering, DTOs, validation, global error handling, JPA, H2, and sample data.

## Requirements

- Java 17+
- Maven 3.9+
- Node.js 18+
- npm 9+

## Run locally

### 1. Start the backend

```bash
cd backend
mvn spring-boot:run
```

API base URL: `http://localhost:8080`

H2 console: `http://localhost:8080/h2-console`  
JDBC URL: `jdbc:h2:mem:crystaldb`  
Username: `sa`  
Password: leave empty.

### 2. Start the frontend

In another terminal:

```bash
cd frontend
npm install
npm start
```

Open `http://localhost:4200`.

## API endpoints

### Customers
- `GET /api/customers?page=0&size=10&search=`
- `GET /api/customers/{id}`
- `POST /api/customers`
- `PUT /api/customers/{id}`
- `DELETE /api/customers/{id}`

### Sales
- `GET /api/sales/summary?period=week&month=2026-10`
- `GET /api/sales/reports?page=0&size=10&period=week&month=2026-10`

### Dashboard
- `GET /api/dashboard/summary?period=week`
- `GET /api/dashboard/revenue?period=week`
- `GET /api/dashboard/satisfaction?period=week`

## Design decisions and assumptions

- Replaced placeholder taglines with concise descriptions that explain each screen.
- Corrected customer labels and form copy (for example, “New Customer”).
- The ambiguous previous-month comparison was interpreted as percentage change versus the previous period.
- Dashboard and sales data are representative seeded data; they are not connected to a live payment or inventory provider.
- Currency is shown in USD to match the sample design labels. Change currency formatting and seed values if the supplied reference screens use another currency.
- H2 keeps first-run setup simple and does not require a separately installed database.

## Architecture

The Angular frontend is organized into page components, core API services, typed models, an HTTP interceptor, and reactive forms. The Spring Boot backend separates controllers, services, repositories, entities, request/response DTOs, and exception handling.

## Suggested ticket board

Create these as separate Jira or Trello tickets and share a view-only board link with the reviewer:

1. Refresh shared navigation and responsive layout.
2. Polish dashboard metrics and charts.
3. Complete sales KPIs, filters, table, pagination, and export.
4. Implement customer CRUD and validation.
5. Implement dashboard, sales, and customer APIs.
6. Seed demo data and standardize API errors.
7. Verify frontend/backend integration.
8. Write setup and design-assumption documentation.

## Git: put this version on a separate branch

If your original project is already cloned locally, copy the contents of this V2 folder into the project working tree, then run:

```bash
git switch -c crystal-ui-v2
git add README.md frontend backend
git commit -m "Refresh Crystal SaaS dashboard UI"
git push -u origin crystal-ui-v2
```

If your existing GitHub repository currently stores only the ZIP file, clone the repository first, create the branch, extract this project into the repository root, and commit the extracted source files. Avoid committing `node_modules`, `target`, or build output.

## Improvements with more time

- Add authentication and role-based access.
- Add controller/service tests and Angular component tests.
- Add sorting, server-side date-range filters, and configurable page sizes.
- Replace seeded dashboard metrics with reporting queries against real transactions.
- Deploy the Angular UI and Spring Boot API separately and configure production CORS/database settings.
