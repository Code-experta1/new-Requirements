package com.assignment.naresh.sahoo.config;

import com.assignment.naresh.sahoo.customer.Customer;
import com.assignment.naresh.sahoo.customer.CustomerRepository;
import com.assignment.naresh.sahoo.sales.Sale;
import com.assignment.naresh.sahoo.sales.SaleRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.math.BigDecimal;
import java.time.LocalDate;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner loadData(CustomerRepository customers, SaleRepository sales) {
        return args -> {
            if (customers.count() == 0) {
                customers.save(new Customer("Olivia Rhye", "Acme Inc.", "olivia@acme.example", "+1 555 0101", new BigDecimal("1200.00")));
                customers.save(new Customer("Phoenix Baker", "Baker Studio", "phoenix@baker.example", "+1 555 0102", new BigDecimal("0.00")));
                customers.save(new Customer("Lana Steiner", "Steiner Group", "lana@steiner.example", "+1 555 0103", new BigDecimal("2450.50")));
                customers.save(new Customer("Demi Wilkinson", "Wilkinson LLC", "demi@wilkinson.example", "+1 555 0104", new BigDecimal("875.00")));
                customers.save(new Customer("Candice Wu", "Wu Creative", "candice@wu.example", "+1 555 0105", new BigDecimal("310.00")));
                customers.save(new Customer("Natali Craig", "Craig Partners", "natali@craig.example", "+1 555 0106", new BigDecimal("0.00")));
                customers.save(new Customer("Drew Cano", "Cano Industries", "drew@cano.example", "+1 555 0107", new BigDecimal("690.00")));
                customers.save(new Customer("Orlando Diggs", "Diggs Digital", "orlando@diggs.example", "+1 555 0108", new BigDecimal("140.00")));
                customers.save(new Customer("Andi Lane", "Lane Works", "andi@lane.example", "+1 555 0109", new BigDecimal("985.00")));
                customers.save(new Customer("Kate Morrison", "Morrison Co.", "kate@morrison.example", "+1 555 0110", new BigDecimal("500.00")));
                customers.save(new Customer("Avery Johnson", "Johnson Studio", "avery@johnson.example", "+1 555 0111", new BigDecimal("0.00")));
                customers.save(new Customer("John Smith", "Smith Retail", "john@smith.example", "+1 555 0112", new BigDecimal("1550.00")));
            }
            if (sales.count() == 0) {
                String[] names = {"Olivia Rhye", "Phoenix Baker", "Lana Steiner", "Demi Wilkinson", "Candice Wu", "Natali Craig", "Drew Cano", "Orlando Diggs", "Andi Lane", "Kate Morrison", "Avery Johnson", "John Smith", "Olivia Rhye"};
                String[] statuses = {"Paid", "Pending", "Paid", "Overdue", "Paid", "Pending", "Paid", "Cancelled", "Paid", "Pending", "Paid", "Overdue", "Paid"};
                for (int i = 0; i < names.length; i++) {
                    sales.save(new Sale("INV-" + (2026001 + i), names[i], LocalDate.now().minusDays(i % 7),
                            i % 2 == 0 ? "Online" : "Offline", statuses[i], new BigDecimal(String.valueOf(220 + i * 85))));
                }
            }
        };
    }
}
