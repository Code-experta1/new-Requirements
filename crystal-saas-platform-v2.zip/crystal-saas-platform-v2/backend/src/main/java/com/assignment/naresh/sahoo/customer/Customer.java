package com.assignment.naresh.sahoo.customer;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private String company;
    @Column(nullable = false, unique = true)
    private String email;
    @Column(nullable = false)
    private String phone;
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal receivables;

    public Customer() {}

    public Customer(String name, String company, String email, String phone, BigDecimal receivables) {
        this.name = name;
        this.company = company;
        this.email = email;
        this.phone = phone;
        this.receivables = receivables;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getCompany() { return company; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public BigDecimal getReceivables() { return receivables; }
    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setCompany(String company) { this.company = company; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setReceivables(BigDecimal receivables) { this.receivables = receivables; }
}
