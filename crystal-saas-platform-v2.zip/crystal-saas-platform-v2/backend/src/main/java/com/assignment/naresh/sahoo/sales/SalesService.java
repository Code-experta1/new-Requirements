package com.assignment.naresh.sahoo.sales;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class SalesService {
    private final SaleRepository repository;

    public SalesService(SaleRepository repository) {
        this.repository = repository;
    }

    public Page<SaleResponse> reports(int page, int size, String period, String month) {
        LocalDate end = LocalDate.now();
        LocalDate start = end.minusDays(6);
        if ("day".equalsIgnoreCase(period)) {
            start = end;
        } else if ("month".equalsIgnoreCase(period) && month != null && month.matches("\\d{4}-\\d{2}")) {
            YearMonth selected = YearMonth.parse(month);
            start = selected.atDay(1);
            end = selected.atEndOfMonth();
        } else if ("all".equalsIgnoreCase(period)) {
            start = LocalDate.of(2000, 1, 1);
        }
        Page<Sale> sales = repository.findBySaleDateBetween(start, end,
                PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by("saleDate").descending()));
        return sales.map(this::toResponse);
    }

    public Map<String, Object> summary(String period, String month) {
        Page<SaleResponse> page = reports(0, 100, period, month);
        BigDecimal total = BigDecimal.ZERO;
        int paid = 0;
        int pending = 0;
        for (SaleResponse sale : page.getContent()) {
            total = total.add(sale.getAmount());
            if ("Paid".equalsIgnoreCase(sale.getStatus())) paid++;
            if ("Pending".equalsIgnoreCase(sale.getStatus())) pending++;
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("totalSales", total);
        result.put("totalOrders", page.getTotalElements());
        result.put("paidOrders", paid);
        result.put("pendingOrders", pending);
        result.put("averageOrderValue", page.getTotalElements() == 0 ? BigDecimal.ZERO :
                total.divide(BigDecimal.valueOf(page.getTotalElements()), 2, java.math.RoundingMode.HALF_UP));
        result.put("period", period == null ? "week" : period);
        return result;
    }

    private SaleResponse toResponse(Sale sale) {
        return new SaleResponse(sale.getId(), sale.getInvoiceNumber(), sale.getCustomerName(), sale.getSaleDate(),
                sale.getChannel(), sale.getStatus(), sale.getAmount());
    }
}
