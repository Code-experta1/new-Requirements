package com.assignment.naresh.sahoo.sales;

import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/sales")
public class SalesController {
    private final SalesService service;

    public SalesController(SalesService service) {
        this.service = service;
    }

    @GetMapping("/summary")
    public Map<String, Object> summary(@RequestParam(defaultValue = "week") String period,
                                       @RequestParam(required = false) String month) {
        return service.summary(period, month);
    }

    @GetMapping("/reports")
    public Page<SaleResponse> reports(@RequestParam(defaultValue = "0") int page,
                                      @RequestParam(defaultValue = "10") int size,
                                      @RequestParam(defaultValue = "week") String period,
                                      @RequestParam(required = false) String month) {
        return service.reports(page, size, period, month);
    }
}
