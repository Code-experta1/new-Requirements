package com.assignment.naresh.sahoo.sales;

import java.math.BigDecimal;
import java.time.LocalDate;

public class SaleResponse {
    private Long id;
    private String invoiceNumber;
    private String customerName;
    private LocalDate saleDate;
    private String channel;
    private String status;
    private BigDecimal amount;

    public SaleResponse(Long id, String invoiceNumber, String customerName, LocalDate saleDate, String channel, String status, BigDecimal amount) {
        this.id = id; this.invoiceNumber = invoiceNumber; this.customerName = customerName;
        this.saleDate = saleDate; this.channel = channel; this.status = status; this.amount = amount;
    }
    public Long getId() { return id; }
    public String getInvoiceNumber() { return invoiceNumber; }
    public String getCustomerName() { return customerName; }
    public LocalDate getSaleDate() { return saleDate; }
    public String getChannel() { return channel; }
    public String getStatus() { return status; }
    public BigDecimal getAmount() { return amount; }
}
