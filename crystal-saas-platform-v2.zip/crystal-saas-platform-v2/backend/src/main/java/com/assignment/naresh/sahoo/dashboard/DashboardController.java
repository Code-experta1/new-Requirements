package com.assignment.naresh.sahoo.dashboard;

import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.*;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
    @GetMapping("/summary")
    public Map<String, Object> summary(@RequestParam(defaultValue = "week") String period) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("totalSale", new BigDecimal("24850.00"));
        result.put("activeOrders", 128);
        result.put("lowStockItems", 12);
        result.put("salesChange", 12.8);
        result.put("ordersChange", 8.2);
        result.put("stockChange", -3.4);
        result.put("period", period);
        return result;
    }

    @GetMapping("/revenue")
    public Map<String, Object> revenue(@RequestParam(defaultValue = "week") String period) {
        List<Map<String, Object>> data = new ArrayList<>();
        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        double multiplier = "day".equalsIgnoreCase(period) ? 0.25 : "month".equalsIgnoreCase(period) ? 3.8 : 1.0;
        double[] online = {1200, 1600, 1350, 2100, 1800, 2500, 2200};
        double[] offline = {900, 1100, 1250, 1000, 1500, 1750, 1400};
        for (int i = 0; i < days.length; i++) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("day", days[i]);
            row.put("online", Math.round(online[i] * multiplier));
            row.put("offline", Math.round(offline[i] * multiplier));
            data.add(row);
        }
        return Map.of("period", period, "data", data);
    }

    @GetMapping("/satisfaction")
    public Map<String, Object> satisfaction(@RequestParam(defaultValue = "week") String period) {
        return Map.of("labels", List.of("Week 1", "Week 2", "Week 3", "Week 4"),
                "lastMonth", List.of(72, 75, 73, 80), "thisMonth", List.of(76, 79, 82, 88),
                "period", period);
    }
}
