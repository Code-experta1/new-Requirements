package com.assignment.naresh.sahoo.customer;

import java.math.BigDecimal;

public class CustomerResponse {
    private Long id;
    private String name;
    private String company;
    private String email;
    private String phone;
    private BigDecimal receivables;

    public CustomerResponse(Long id, String name, String company, String email, String phone, BigDecimal receivables) {
        this.id = id;
        this.name = name;
        this.company = company;
        this.email = email;
        this.phone = phone;
        this.receivables = receivables;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getCompany() { return company; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public BigDecimal getReceivables() { return receivables; }
}
