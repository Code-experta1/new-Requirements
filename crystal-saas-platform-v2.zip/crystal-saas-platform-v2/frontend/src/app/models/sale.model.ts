export interface Sale {
  id: number;
  invoiceNumber: string;
  customerName: string;
  saleDate: string;
  channel: string;
  status: string;
  amount: number;
}

export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  number: number;
  size: number;
}
