export interface Customer {
  id: number;
  name: string;
  company: string;
  email: string;
  phone: string;
  receivables: number;
}

export interface CustomerRequest {
  name: string;
  company: string;
  email: string;
  phone: string;
  receivables: number;
}

export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  number: number;
  size: number;
}
