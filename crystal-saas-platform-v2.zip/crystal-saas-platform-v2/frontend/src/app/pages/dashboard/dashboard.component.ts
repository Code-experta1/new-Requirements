import { Component, OnInit } from '@angular/core';
import { ChartConfiguration, ChartOptions } from 'chart.js';
import { DashboardService } from '../../core/dashboard.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit {
  readonly Math = Math;

  period = 'week';
  summary: any = { totalSale: 24850, activeOrders: 128, lowStockItems: 12, salesChange: 12.8, ordersChange: 8.2, stockChange: -3.4 };
  loading = true;
  error = '';

  revenueData: ChartConfiguration<'bar'>['data'] = { labels: [], datasets: [] };
  revenueOptions: ChartOptions<'bar'> = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } } },
    scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: '#edf0f5' } } }
  };
  satisfactionData: ChartConfiguration<'line'>['data'] = { labels: [], datasets: [] };
  satisfactionOptions: ChartOptions<'line'> = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } } },
    scales: { x: { grid: { display: false } }, y: { min: 50, max: 100, ticks: { callback: value => `${value}%` } } }
  };

  constructor(private dashboard: DashboardService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.error = '';
    this.dashboard.getSummary(this.period).subscribe({
      next: data => { this.summary = data; this.loading = false; },
      error: () => { this.error = 'Unable to load dashboard summary. Check that the backend is running.'; this.loading = false; }
    });
    this.dashboard.getRevenue(this.period).subscribe({
      next: response => {
        this.revenueData = {
          labels: response.data.map((item: any) => item.day),
          datasets: [
            { label: 'Online sales', data: response.data.map((item: any) => item.online), backgroundColor: '#635bff', borderRadius: 5, barPercentage: 0.55 },
            { label: 'Offline sales', data: response.data.map((item: any) => item.offline), backgroundColor: '#c7c4ff', borderRadius: 5, barPercentage: 0.55 }
          ]
        };
      },
      error: () => this.error = 'Unable to load revenue data.'
    });
    this.dashboard.getSatisfaction(this.period).subscribe({
      next: response => {
        this.satisfactionData = {
          labels: response.labels,
          datasets: [
            { label: 'Last month', data: response.lastMonth, borderColor: '#b7b3ff', backgroundColor: 'rgba(183,179,255,0.12)', fill: true, tension: 0.4, pointRadius: 3 },
            { label: 'This month', data: response.thisMonth, borderColor: '#635bff', backgroundColor: 'rgba(99,91,255,0.10)', fill: true, tension: 0.4, pointRadius: 3 }
          ]
        };
      },
      error: () => this.error = 'Unable to load satisfaction data.'
    });
  }
}
